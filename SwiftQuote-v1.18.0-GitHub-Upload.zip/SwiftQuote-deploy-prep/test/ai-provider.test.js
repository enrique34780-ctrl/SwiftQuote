import test from 'node:test';
import assert from 'node:assert/strict';
import { createAIProvider } from '../ai-provider.js';

const okGemini = text => ({
  ok: true,
  async json() { return { candidates: [{ content: { parts: [{ text }] } }] }; },
});

test('reports unconfigured when neither provider key exists', async () => {
  const ai = createAIProvider();
  assert.equal(ai.configured, false);
  await assert.rejects(ai.generateText({ system: 'sys', user: 'usr' }), /not configured/);
});

test('uses OpenAI first when both providers are configured', async () => {
  let geminiCalls = 0;
  const ai = createAIProvider({
    openai: { responses: { create: async input => ({ output_text: `ok:${input.model}:${input.max_output_tokens}` }) } },
    openaiApiKey: 'secret-openai',
    geminiApiKey: 'secret-gemini',
    fetchImpl: async () => { geminiCalls++; return okGemini('fallback'); },
  });
  assert.equal(await ai.generateText({ system: 'sys', user: 'usr', maxOutputTokens: 50 }), 'ok:gpt-4.1-mini:50');
  assert.equal(geminiCalls, 0);
});

test('uses Gemini alone and sends key only as a server-side header', async () => {
  let called;
  const ai = createAIProvider({
    geminiApiKey: 'gemini-secret', geminiModel: 'gemini-3.8-flash',
    fetchImpl: async (url, options) => { called = { url, options, payload: JSON.parse(options.body) }; return okGemini('gemini answer'); },
  });
  assert.equal(await ai.generateText({ system: 'instructions', user: 'a task', maxOutputTokens: 44, json: true }), 'gemini answer');
  assert.match(called.url, /models\/gemini-3\.8-flash:generateContent$/);
  assert.equal(called.options.headers['x-goog-api-key'], 'gemini-secret');
  assert.equal(called.url.includes('gemini-secret'), false);
  assert.equal(called.payload.systemInstruction.parts[0].text, 'instructions');
  assert.equal(called.payload.generationConfig.maxOutputTokens, 44);
  assert.equal(called.payload.generationConfig.responseMimeType, 'application/json');
  assert.equal(called.options.redirect, 'error');
});

test('falls back to Gemini when OpenAI fails without revealing secrets in errors', async () => {
  let geminiCalls = 0;
  const ai = createAIProvider({
    openai: { responses: { create: async () => { throw new Error('OpenAI key secret-openai leaked'); } } },
    openaiApiKey: 'secret-openai', geminiApiKey: 'secret-gemini',
    fetchImpl: async () => { geminiCalls++; return okGemini('recovered'); },
  });
  assert.equal(await ai.generateText({ system: 's', user: 'u' }), 'recovered');
  assert.equal(geminiCalls, 1);
});

test('throws sanitized error when all configured providers fail', async () => {
  const ai = createAIProvider({
    openai: { responses: { create: async () => { throw new Error('secret-openai'); } } },
    openaiApiKey: 'secret-openai', geminiApiKey: 'secret-gemini',
    fetchImpl: async () => ({ ok: false, async json() { return { error: 'secret-gemini' }; } }),
  });
  await assert.rejects(ai.generateText({ system: 's', user: 'u' }), err => {
    assert.match(err.message, /unavailable/);
    assert.doesNotMatch(err.message, /secret/);
    return true;
  });
});


test('Gemini timeout stays active while response body is being read', async () => {
  const ai = createAIProvider({
    geminiApiKey: 'gemini-secret',
    timeoutMs: 5,
    fetchImpl: async (_url, { signal }) => ({
      ok: true,
      json: () => new Promise((_resolve, reject) => {
        if (signal.aborted) reject(new Error('aborted'));
        else signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true });
      }),
    }),
  });
  await assert.rejects(ai.generateText({ system: 's', user: 'u' }), /unavailable/);
});

test('bounds prompt length and clamps output tokens', async () => {
  let sent;
  const ai = createAIProvider({
    geminiApiKey: 'key',
    fetchImpl: async (_url, options) => { sent = JSON.parse(options.body); return okGemini('ok'); },
  });
  await ai.generateText({ system: 's'.repeat(20_000), user: 'u'.repeat(20_000), maxOutputTokens: 99_999 });
  assert.equal(sent.systemInstruction.parts[0].text.length, 12_000);
  assert.equal(sent.contents[0].parts[0].text.length, 12_000);
  assert.equal(sent.generationConfig.maxOutputTokens, 2_000);
});

test('falls back to Gemini when OpenAI returns empty output', async () => {
  let geminiCalls = 0;
  const ai = createAIProvider({
    openai: { responses: { create: async () => ({ output_text: '  ' }) } },
    openaiApiKey: 'openai-key', geminiApiKey: 'gemini-key',
    fetchImpl: async () => { geminiCalls++; return okGemini('fallback after empty'); },
  });
  assert.equal(await ai.generateText({ system: 's', user: 'u' }), 'fallback after empty');
  assert.equal(geminiCalls, 1);
});

test('handles a successful Gemini response with no candidate text safely', async () => {
  const ai = createAIProvider({
    geminiApiKey: 'key',
    fetchImpl: async () => ({ ok: true, async json() { return { candidates: [] }; } }),
  });
  await assert.rejects(ai.generateText({ system: 's', user: 'u' }), /unavailable/);
});

test('sanitizes malformed Gemini JSON response errors', async () => {
  const ai = createAIProvider({
    geminiApiKey: 'key-secret',
    fetchImpl: async () => ({ ok: true, async json() { throw new Error('body contains key-secret'); } }),
  });
  await assert.rejects(ai.generateText({ system: 's', user: 'u' }), err => {
    assert.match(err.message, /unavailable/);
    assert.doesNotMatch(err.message, /key-secret/);
    return true;
  });
});

test('Gemini API URL encodes model path segment', async () => {
  let requestedUrl = '';
  const ai = createAIProvider({
    geminiApiKey: 'key', geminiModel: 'test model/unsafe',
    fetchImpl: async url => { requestedUrl = url; return okGemini('ok'); },
  });
  await ai.generateText({ system: 's', user: 'u' });
  assert.match(requestedUrl, /test%20model%2Funsafe:generateContent$/);
});
